var searchData=
[
  ['parse_5fcx',['parse_cx',['../classsp_1_1parser.html#ae2481f46a30529b252107b393923c72b',1,'sp::parser']]],
  ['parser',['parser',['../classsp_1_1parser.html#a435c5279a748a8fcbc0efa2c06fe3794',1,'sp::parser']]],
  ['phasez',['phasez',['../group__filter.html#ga796fdc95e378df7d70b252d7979a6eec',1,'sp']]],
  ['psd',['psd',['../group__spectrum.html#ga5e16e1d3674bebd9e672e27e81503213',1,'sp::psd(arma::Col&lt; T1 &gt; &amp;x, arma::vec &amp;W)'],['../group__spectrum.html#gae0aa7a375f79396585aa6cb22d3ec4a5',1,'sp::psd(arma::Col&lt; T1 &gt; &amp;x)']]],
  ['pwelch',['pwelch',['../group__spectrum.html#ga4897ba3d9d74cc420b73b0618f0ca9be',1,'sp']]],
  ['pwelch_5fph',['pwelch_ph',['../group__spectrum.html#gac6bf8cb38ebbf60389576ae6e015e855',1,'sp']]]
];
