var searchData=
[
  ['ifft',['ifft',['../classsp_1_1_f_f_t_w.html#a8cdbeee097e35bc525fd6194725ee3ff',1,'sp::FFTW::ifft(arma::cx_vec &amp;Pxx, arma::vec &amp;x)'],['../classsp_1_1_f_f_t_w.html#a49e615fc778231d27fb64a19fce28f45',1,'sp::FFTW::ifft(arma::cx_vec &amp;Pxx)']]],
  ['ifft_5fcx',['ifft_cx',['../classsp_1_1_f_f_t_w.html#a045303d4027ee2cebf7acc94f9a6a77b',1,'sp::FFTW::ifft_cx(arma::cx_vec &amp;Pxx, arma::cx_vec &amp;x)'],['../classsp_1_1_f_f_t_w.html#aaafa35957d8433550f293b407f5a62dc',1,'sp::FFTW::ifft_cx(arma::cx_vec &amp;Pxx)']]],
  ['iir_5ffilt',['IIR_filt',['../classsp_1_1_i_i_r__filt.html#a5049d36219530673432b21d95c903d2c',1,'sp::IIR_filt']]],
  ['iir_5ffilt',['IIR_filt',['../classsp_1_1_i_i_r__filt.html',1,'sp']]]
];
