var searchData=
[
  ['fd_5ffilter',['fd_filter',['../group__filter.html#ga6020bfa713362ac66154a984483527a5',1,'sp']]],
  ['fft',['fft',['../classsp_1_1_f_f_t_w.html#ac64d3666f8c9602e1a9e74afd676f405',1,'sp::FFTW::fft(arma::vec &amp;x, arma::cx_vec &amp;Pxx)'],['../classsp_1_1_f_f_t_w.html#a1009e05281f55f63772ecbd2d67b4f53',1,'sp::FFTW::fft(arma::vec &amp;x)']]],
  ['fft_5fcx',['fft_cx',['../classsp_1_1_f_f_t_w.html#af3d3a1c61486e257a56389083169ef62',1,'sp::FFTW::fft_cx(arma::cx_vec &amp;x, arma::cx_vec &amp;Pxx)'],['../classsp_1_1_f_f_t_w.html#a8821465ad3f60607b4add3ad58167493',1,'sp::FFTW::fft_cx(arma::cx_vec &amp;x)']]],
  ['fftw',['FFTW',['../classsp_1_1_f_f_t_w.html#af4cf9427d75e6f191021b008041e740e',1,'sp::FFTW']]],
  ['filter',['filter',['../classsp_1_1_f_i_r__filt.html#a2a83dc2e6bc02343ff51247c5e62e474',1,'sp::FIR_filt::filter()'],['../classsp_1_1_i_i_r__filt.html#af9aa05bfbbf6236eb166a76e965b3955',1,'sp::IIR_filt::filter()']]],
  ['fir1',['fir1',['../group__filter.html#gaa9685b6e1891ce132d27c98f6630fa76',1,'sp']]],
  ['fir_5ffilt',['FIR_filt',['../classsp_1_1_f_i_r__filt.html#abc87a2054ab2d8aba596aa06d1fc9ca4',1,'sp::FIR_filt']]],
  ['flattopwin',['flattopwin',['../group__window.html#ga5c2c0e240d49c3e384c882989c5864d3',1,'sp']]],
  ['freq',['freq',['../group__filter.html#gaa920dbd65a49d0b7a9608e23318bb054',1,'sp']]],
  ['freqz',['freqz',['../group__filter.html#ga8c47562c214aeb78e5dfe7e2c2cd3eb2',1,'sp']]]
];
