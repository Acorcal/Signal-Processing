var searchData=
[
  ['linestyle',['linestyle',['../classsp_1_1gplot.html#a0c1e4ef15dbbbf83b4aa48024f5c3223',1,'sp::gplot']]]
];
