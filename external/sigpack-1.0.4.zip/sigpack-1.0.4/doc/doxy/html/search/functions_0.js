var searchData=
[
  ['angle',['angle',['../group__math.html#gabb742e193532b11b0d204d11ea45c74d',1,'sp::angle(std::complex&lt; T &gt; &amp;x)'],['../group__math.html#gaff142921df37f564f1f17161a95f6b81',1,'sp::angle(arma::cx_vec &amp;x)'],['../group__math.html#gabd660fba0f64c04dbd5dc305ed3cbc40',1,'sp::angle(arma::cx_mat &amp;x)']]]
];
