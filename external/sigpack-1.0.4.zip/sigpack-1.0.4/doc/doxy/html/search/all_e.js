var searchData=
[
  ['p',['p',['../classsp_1_1_f_f_t_w.html#a734f726fa7a2f53b0b5106b91aed368c',1,'sp::FFTW']]],
  ['par_5fmap',['par_map',['../classsp_1_1parser.html#aeb5e47dbf42795afb988f3d60f8fd8f7',1,'sp::parser']]],
  ['parse_5fcx',['parse_cx',['../classsp_1_1parser.html#ae2481f46a30529b252107b393923c72b',1,'sp::parser']]],
  ['parser',['parser',['../classsp_1_1parser.html',1,'sp']]],
  ['parser',['parser',['../classsp_1_1parser.html#a435c5279a748a8fcbc0efa2c06fe3794',1,'sp::parser::parser()'],['../group__parser.html',1,'(Global Namespace)']]],
  ['parser_2eh',['parser.h',['../parser_8h.html',1,'']]],
  ['phasez',['phasez',['../group__filter.html#ga796fdc95e378df7d70b252d7979a6eec',1,'sp']]],
  ['pi',['PI',['../group__math.html#ga034dbffa92d82e870d4cc1a9c5b9ac07',1,'sp']]],
  ['pi_5f2',['PI_2',['../group__math.html#ga9fd397ecb93b285615809a1018268ed7',1,'sp']]],
  ['psd',['psd',['../group__spectrum.html#ga5e16e1d3674bebd9e672e27e81503213',1,'sp::psd(arma::Col&lt; T1 &gt; &amp;x, arma::vec &amp;W)'],['../group__spectrum.html#gae0aa7a375f79396585aa6cb22d3ec4a5',1,'sp::psd(arma::Col&lt; T1 &gt; &amp;x)']]],
  ['pwelch',['pwelch',['../group__spectrum.html#ga4897ba3d9d74cc420b73b0618f0ca9be',1,'sp']]],
  ['pwelch_5fph',['pwelch_ph',['../group__spectrum.html#gac6bf8cb38ebbf60389576ae6e015e855',1,'sp']]]
];
