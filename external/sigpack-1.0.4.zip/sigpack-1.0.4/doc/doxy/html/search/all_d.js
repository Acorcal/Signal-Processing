var searchData=
[
  ['operator_28_29',['operator()',['../classsp_1_1_f_i_r__filt.html#a0edc0d91e0be9cd5cc1d29b72cf2a083',1,'sp::FIR_filt::operator()()'],['../classsp_1_1_i_i_r__filt.html#a9625a5581f186fe8c017f0f8e485c8c9',1,'sp::IIR_filt::operator()()'],['../classsp_1_1_delay.html#a0976a0c0e3ed7b26e1d1d2c457ecea2d',1,'sp::Delay::operator()()']]]
];
