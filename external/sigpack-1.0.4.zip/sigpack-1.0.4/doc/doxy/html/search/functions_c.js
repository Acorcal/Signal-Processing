var searchData=
[
  ['triang',['triang',['../group__window.html#gadf0b5d598da5f3da87d1fd3f979cea12',1,'sp']]]
];
