var searchData=
[
  ['unwrap',['unwrap',['../group__math.html#ga0e0aa2825c582d9826f2bb0ba5e0768c',1,'sp']]],
  ['update_5fcoeffs',['update_coeffs',['../classsp_1_1_f_i_r__filt.html#a26a52c388ada953b17c06b76843fce40',1,'sp::FIR_filt::update_coeffs()'],['../classsp_1_1_i_i_r__filt.html#abf28a145db10611294bcaeb572888482',1,'sp::IIR_filt::update_coeffs()']]],
  ['upfir',['upfir',['../group__resampling.html#gaad4861c80c55f69b9d238619e7685899',1,'sp']]],
  ['upsample',['upsample',['../group__resampling.html#ga84878fcbf4e7f58d3b8a23f54b7fc986',1,'sp']]]
];
