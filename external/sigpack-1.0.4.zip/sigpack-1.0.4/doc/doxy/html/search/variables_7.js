var searchData=
[
  ['n',['N',['../classsp_1_1_f_f_t_w.html#a277679f19b7f492d4591c582c351ff59',1,'sp::FFTW::N()'],['../classsp_1_1_f_i_r__filt.html#aeb9e1cbc706a752b931e7bd2853051eb',1,'sp::FIR_filt::N()'],['../classsp_1_1_i_i_r__filt.html#ae1bf0c9cf61308640a1aa197691fb440',1,'sp::IIR_filt::N()']]],
  ['ninv',['Ninv',['../classsp_1_1_f_f_t_w.html#ace2978594d6aa0d6a66a84fa9d31cd51',1,'sp::FFTW']]]
];
