var searchData=
[
  ['besseli0',['besseli0',['../group__math.html#ga0e8bf510a75858ae61878fea1a979474',1,'sp']]],
  ['blackman',['blackman',['../group__window.html#ga9def8d5dca4cdffb89f3e8c482d59d02',1,'sp']]],
  ['blackmanharris',['blackmanharris',['../group__window.html#gac42ca2ed88658b1dd58399961ce74998',1,'sp']]]
];
