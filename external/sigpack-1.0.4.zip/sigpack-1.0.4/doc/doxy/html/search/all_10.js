var searchData=
[
  ['set_5fcoeffs',['set_coeffs',['../classsp_1_1_f_i_r__filt.html#a6c409eaf598eb558a658e4a7ab815ba6',1,'sp::FIR_filt::set_coeffs()'],['../classsp_1_1_i_i_r__filt.html#afb2b23eaa8e8d4b14a5339b0a405954c',1,'sp::IIR_filt::set_coeffs()']]],
  ['set_5fdelay',['set_delay',['../classsp_1_1_delay.html#a8b51c856bb5c32839a3ad9bca0ea9587',1,'sp::Delay']]],
  ['sigpack_2eh',['sigpack.h',['../sigpack_8h.html',1,'']]],
  ['sinc',['sinc',['../group__math.html#ga183c5d540661c7de4f3b25a6d990d689',1,'sp']]],
  ['sp',['sp',['../namespacesp.html',1,'']]],
  ['specgram',['specgram',['../group__spectrum.html#gabd389539c30951c398ecdb1f3a608ccf',1,'sp']]],
  ['specgram_5fcx',['specgram_cx',['../group__spectrum.html#ga83ffadc71d810e04431bf192e5a864ec',1,'sp']]],
  ['specgram_5fph',['specgram_ph',['../group__spectrum.html#ga6320a75923425735e1e77718ae4f8b8a',1,'sp']]],
  ['spectrum',['spectrum',['../group__spectrum.html#gad822b3ac0759a10978b08036f21a7b2d',1,'sp::spectrum()'],['../group__spectrum.html',1,'(Global Namespace)']]],
  ['spectrum_2eh',['spectrum.h',['../spectrum_8h.html',1,'']]]
];
