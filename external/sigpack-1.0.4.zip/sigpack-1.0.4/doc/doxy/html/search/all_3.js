var searchData=
[
  ['d',['D',['../classsp_1_1_delay.html#aad8518561f2ab488e6e851f84d1b1694',1,'sp::Delay']]],
  ['delay',['Delay',['../classsp_1_1_delay.html',1,'sp']]],
  ['delay',['delay',['../classsp_1_1_delay.html#ac7c1ec0a67f68c1428ea46aea1ae40df',1,'sp::Delay::delay(arma::Col&lt; T1 &gt; &amp;in)'],['../classsp_1_1_delay.html#aa03a5548a51d67d1dc913d7f2a6602df',1,'sp::Delay::Delay()'],['../classsp_1_1_delay.html#a7a0e162943e08f88828add904639ed06',1,'sp::Delay::Delay(int _D)']]],
  ['downfir',['downfir',['../group__resampling.html#gac268657bb2f9ef762d593df8220b7eb0',1,'sp']]],
  ['downsample',['downsample',['../group__resampling.html#ga5c45047ed5402601536c6581601b6188',1,'sp']]]
];
