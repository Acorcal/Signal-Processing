var searchData=
[
  ['fftw',['FFTW',['../classsp_1_1_f_f_t_w.html',1,'sp']]],
  ['fir_5ffilt',['FIR_filt',['../classsp_1_1_f_i_r__filt.html',1,'sp']]]
];
