var searchData=
[
  ['gnucmd',['gnucmd',['../classsp_1_1gplot.html#a69ddfcc2abac2d13f0739f6923988af1',1,'sp::gplot']]]
];
