var searchData=
[
  ['timing',['Timing',['../group__timing.html',1,'']]],
  ['timing_2eh',['timing.h',['../timing_8h.html',1,'']]],
  ['triang',['triang',['../group__window.html#gadf0b5d598da5f3da87d1fd3f979cea12',1,'sp']]]
];
