var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvw~",
  1: "dfgip",
  2: "s",
  3: "bfgprstw",
  4: "abcdfghikopstuv~",
  5: "abcdglmnpr",
  6: "fgmprstw",
  7: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Modules",
  7: "Pages"
};

